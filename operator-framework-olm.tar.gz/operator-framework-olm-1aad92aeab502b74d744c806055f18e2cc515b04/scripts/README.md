# Syncing downstream OLM

All of the staged repositories live in the top level `staging` directory.

Note: the process for porting upstream commits downstream is outlined in the [OLM downstreaming guide](https://docs.google.com/document/d/139yXeOqAJbV1ndC7Q4NbaOtzbSdNpcuJan0iemORd3g/edit#).
