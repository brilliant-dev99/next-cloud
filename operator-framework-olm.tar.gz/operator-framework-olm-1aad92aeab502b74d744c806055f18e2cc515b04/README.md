# operator-framework-olm

This repository is a monorepo superset of the projects that comprises the Operator Lifecycle Manager runtime and tooling for use with Openshift.